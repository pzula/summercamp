-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 18, 2013 at 10:18 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lcbsummercamp`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_sessions_view`
--
DROP VIEW IF EXISTS `all_sessions_view`;
CREATE TABLE IF NOT EXISTS `all_sessions_view` (
`session_combo` int(3)
,`campus_id` int(4)
,`campus_name` varchar(255)
,`session_id` int(3)
,`start_date` date
,`end_date` date
,`end_display_date` date
,`registrant_count` bigint(21)
);
-- --------------------------------------------------------

--
-- Table structure for table `registrants`
--

DROP TABLE IF EXISTS `registrants`;
CREATE TABLE IF NOT EXISTS `registrants` (
  `registrant_id` int(4) NOT NULL AUTO_INCREMENT,
  `session_combo` int(3) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `tshirt` varchar(255) NOT NULL,
  PRIMARY KEY (`registrant_id`),
  KEY `session_combo` (`session_combo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `registrants`
--

INSERT INTO `registrants` (`registrant_id`, `session_combo`, `first_name`, `last_name`, `email_address`, `tshirt`) VALUES
(5, 4, 'First', 'Last', 'jarjar@starwars.com', 'X-Large');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

DROP TABLE IF EXISTS `schools`;
CREATE TABLE IF NOT EXISTS `schools` (
  `campus_id` int(4) NOT NULL,
  `campus_name` varchar(255) NOT NULL,
  UNIQUE KEY `campus_id` (`campus_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`campus_id`, `campus_name`) VALUES
(5, 'Le Cordon Bleu in Scottsdale'),
(6, 'Le Cordon Bleu in Porland'),
(7, 'Le Cordon Bleu in San Francisco'),
(8, 'Le Cordon Bleu in Los Angeles'),
(32, 'Le Cordon Bleu in Chicago'),
(46, 'Le Cordon Bleu in Orlando'),
(49, 'Le Cordon Bleu in Austin'),
(55, 'Le Cordon Bleu in Las Vegas'),
(58, 'Le Cordon Bleu in Atlanta'),
(88, 'Le Cordon Bleu in Miami'),
(97, 'Le Cordon Bleu in Boston'),
(99, 'Le Cordon Bleu in MSP'),
(107, 'Le Cordon Bleu in Sacramento'),
(109, 'Le Cordon Bleu in Dallas'),
(112, 'Le Cordon Bleu in St. Louis'),
(113, 'Le Cordon Bleu in Seattle');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `session_combo` int(3) NOT NULL AUTO_INCREMENT,
  `session_id` int(3) NOT NULL,
  `campus_id` int(4) NOT NULL,
  PRIMARY KEY (`session_combo`),
  UNIQUE KEY `session_combo` (`session_combo`),
  KEY `campus_id` (`campus_id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_combo`, `session_id`, `campus_id`) VALUES
(1, 1, 5),
(2, 1, 6),
(3, 1, 7),
(4, 1, 8),
(5, 1, 32),
(6, 1, 46),
(7, 1, 49),
(8, 1, 55),
(9, 1, 58),
(10, 1, 88),
(11, 1, 97),
(12, 1, 99),
(13, 1, 107),
(14, 1, 109),
(15, 1, 112),
(16, 1, 113),
(17, 2, 5),
(18, 2, 6),
(19, 2, 7),
(20, 2, 8),
(21, 2, 32),
(22, 2, 46),
(23, 2, 49),
(24, 2, 55),
(25, 2, 58),
(26, 2, 88),
(27, 2, 97),
(28, 2, 99),
(29, 2, 107),
(30, 2, 109),
(31, 2, 112),
(32, 2, 113),
(33, 3, 5),
(34, 3, 6),
(35, 3, 7),
(36, 3, 8),
(37, 3, 32),
(38, 3, 46),
(39, 3, 49),
(40, 3, 55),
(41, 3, 58),
(42, 3, 88),
(43, 3, 97),
(44, 3, 99),
(45, 3, 107),
(46, 3, 109),
(47, 3, 112),
(48, 3, 113);

-- --------------------------------------------------------

--
-- Table structure for table `session_dates`
--

DROP TABLE IF EXISTS `session_dates`;
CREATE TABLE IF NOT EXISTS `session_dates` (
  `session_id` int(3) NOT NULL AUTO_INCREMENT,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `end_display_date` date NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `session_dates`
--

INSERT INTO `session_dates` (`session_id`, `start_date`, `end_date`, `end_display_date`) VALUES
(1, '2013-07-05', '2013-07-06', '2013-06-28'),
(2, '2013-07-12', '2013-07-13', '2013-07-05'),
(3, '2013-07-19', '2013-07-20', '2013-07-12');

-- --------------------------------------------------------

--
-- Structure for view `all_sessions_view`
--
DROP TABLE IF EXISTS `all_sessions_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_sessions_view` AS select `sessions`.`session_combo` AS `session_combo`,`schools`.`campus_id` AS `campus_id`,`schools`.`campus_name` AS `campus_name`,`session_dates`.`session_id` AS `session_id`,`session_dates`.`start_date` AS `start_date`,`session_dates`.`end_date` AS `end_date`,`session_dates`.`end_display_date` AS `end_display_date`,(select count(`registrants`.`registrant_id`) from `registrants` where (`registrants`.`session_combo` = `sessions`.`session_combo`)) AS `registrant_count` from ((`sessions` left join `schools` on((`schools`.`campus_id` = `sessions`.`campus_id`))) left join `session_dates` on((`sessions`.`session_id` = `session_dates`.`session_id`)));

--
-- Constraints for dumped tables
--

--
-- Constraints for table `registrants`
--
ALTER TABLE `registrants`
  ADD CONSTRAINT `registrants_ibfk_1` FOREIGN KEY (`session_combo`) REFERENCES `sessions` (`session_combo`) ON UPDATE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`campus_id`) REFERENCES `schools` (`campus_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `session_dates` (`session_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
